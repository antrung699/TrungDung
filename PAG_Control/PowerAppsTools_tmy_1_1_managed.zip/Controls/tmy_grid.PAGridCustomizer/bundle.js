/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./PAGridCustomizer/customizers/CellEditorOverrides.tsx":
/*!**************************************************************!*\
  !*** ./PAGridCustomizer/customizers/CellEditorOverrides.tsx ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("\n\nvar _a;\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.cellEditorOverrides = void 0;\nvar react_1 = __webpack_require__(/*! @fluentui/react */ \"@fluentui/react\");\nvar React = __webpack_require__(/*! react */ \"react\");\nvar index_1 = __webpack_require__(/*! ../index */ \"./PAGridCustomizer/index.ts\");\nexports.cellEditorOverrides = (_a = {}, _a[\"Text\"] = function (props, col) {\n  if (index_1.stateData.Settings.length > 0 && index_1.stateData.Settings[0].attributes.indexOf(col.colDefs[col.columnIndex].name.toLowerCase()) > -1) {\n    return React.createElement(react_1.Label, null, stringify(props.value));\n  }\n}, _a[\"Email\"] = function (props, col) {\n  if (index_1.stateData.Settings.length > 0 && index_1.stateData.Settings[0].attributes.indexOf(col.colDefs[col.columnIndex].name.toLowerCase()) > -1) {\n    return React.createElement(react_1.Label, null, stringify(props.value));\n  }\n}, _a[\"Phone\"] = function (props, col) {\n  if (index_1.stateData.Settings.length > 0 && index_1.stateData.Settings[0].attributes.indexOf(col.colDefs[col.columnIndex].name.toLowerCase()) > -1) {\n    return React.createElement(react_1.Label, null, stringify(props.value));\n  }\n}, _a[\"Ticker\"] = function (props, col) {\n  if (index_1.stateData.Settings.length > 0 && index_1.stateData.Settings[0].attributes.indexOf(col.colDefs[col.columnIndex].name.toLowerCase()) > -1) {\n    return React.createElement(react_1.Label, null, stringify(props.value));\n  }\n}, _a[\"URL\"] = function (props, col) {\n  if (index_1.stateData.Settings.length > 0 && index_1.stateData.Settings[0].attributes.indexOf(col.colDefs[col.columnIndex].name.toLowerCase()) > -1) {\n    return React.createElement(react_1.Label, null, stringify(props.value));\n  }\n}, _a[\"TextArea\"] = function (props, col) {\n  if (index_1.stateData.Settings.length > 0 && index_1.stateData.Settings[0].attributes.indexOf(col.colDefs[col.columnIndex].name.toLowerCase()) > -1) {\n    return React.createElement(react_1.Label, null, stringify(props.value));\n  }\n}, _a[\"Lookup\"] = function (props, col) {\n  if (index_1.stateData.Settings.length > 0 && index_1.stateData.Settings[0].attributes.indexOf(col.colDefs[col.columnIndex].name.toLowerCase()) > -1) {\n    return React.createElement(react_1.Label, null, stringify(props.value));\n  }\n}, _a[\"Customer\"] = function (props, col) {\n  if (index_1.stateData.Settings.length > 0 && index_1.stateData.Settings[0].attributes.indexOf(col.colDefs[col.columnIndex].name.toLowerCase()) > -1) {\n    return React.createElement(react_1.Label, null, stringify(props.value));\n  }\n}, _a[\"Owner\"] = function (props, col) {\n  if (index_1.stateData.Settings.length > 0 && index_1.stateData.Settings[0].attributes.indexOf(col.colDefs[col.columnIndex].name.toLowerCase()) > -1) {\n    return React.createElement(react_1.Label, null, stringify(props.value));\n  }\n}, _a[\"MultiSelectPicklist\"] = function (props, col) {\n  if (index_1.stateData.Settings.length > 0 && index_1.stateData.Settings[0].attributes.indexOf(col.colDefs[col.columnIndex].name.toLowerCase()) > -1) {\n    return React.createElement(react_1.Label, null, stringify(props.value));\n  }\n}, _a[\"OptionSet\"] = function (props, col) {\n  if (index_1.stateData.Settings.length > 0 && index_1.stateData.Settings[0].attributes.indexOf(col.colDefs[col.columnIndex].name.toLowerCase()) > -1) {\n    return React.createElement(react_1.Label, null, stringify(props.value));\n  }\n}, _a[\"TwoOptions\"] = function (props, col) {\n  if (index_1.stateData.Settings.length > 0 && index_1.stateData.Settings[0].attributes.indexOf(col.colDefs[col.columnIndex].name.toLowerCase()) > -1) {\n    return React.createElement(react_1.Label, null, stringify(props.value));\n  }\n}, _a[\"Duration\"] = function (props, col) {\n  if (index_1.stateData.Settings.length > 0 && index_1.stateData.Settings[0].attributes.indexOf(col.colDefs[col.columnIndex].name.toLowerCase()) > -1) {\n    return React.createElement(react_1.Label, null, stringify(props.value));\n  }\n}, _a[\"Language\"] = function (props, col) {\n  if (index_1.stateData.Settings.length > 0 && index_1.stateData.Settings[0].attributes.indexOf(col.colDefs[col.columnIndex].name.toLowerCase()) > -1) {\n    return React.createElement(react_1.Label, null, stringify(props.value));\n  }\n}, _a[\"Multiple\"] = function (props, col) {\n  if (index_1.stateData.Settings.length > 0 && index_1.stateData.Settings[0].attributes.indexOf(col.colDefs[col.columnIndex].name.toLowerCase()) > -1) {\n    return React.createElement(react_1.Label, null, stringify(props.value));\n  }\n}, _a[\"TimeZone\"] = function (props, col) {\n  if (index_1.stateData.Settings.length > 0 && index_1.stateData.Settings[0].attributes.indexOf(col.colDefs[col.columnIndex].name.toLowerCase()) > -1) {\n    return React.createElement(react_1.Label, null, stringify(props.value));\n  }\n}, _a[\"Integer\"] = function (props, col) {\n  if (index_1.stateData.Settings.length > 0 && index_1.stateData.Settings[0].attributes.indexOf(col.colDefs[col.columnIndex].name.toLowerCase()) > -1) {\n    return React.createElement(react_1.Label, null, stringify(props.value));\n  }\n}, _a[\"Currency\"] = function (props, col) {\n  if (index_1.stateData.Settings.length > 0 && index_1.stateData.Settings[0].attributes.indexOf(col.colDefs[col.columnIndex].name.toLowerCase()) > -1) {\n    return React.createElement(react_1.Label, null, stringify(props.value));\n  }\n}, _a[\"Decimal\"] = function (props, col) {\n  if (index_1.stateData.Settings.length > 0 && index_1.stateData.Settings[0].attributes.indexOf(col.colDefs[col.columnIndex].name.toLowerCase()) > -1) {\n    return React.createElement(react_1.Label, null, stringify(props.value));\n  }\n}, _a[\"FloatingPoint\"] = function (props, col) {\n  if (index_1.stateData.Settings.length > 0 && index_1.stateData.Settings[0].attributes.indexOf(col.colDefs[col.columnIndex].name.toLowerCase()) > -1) {\n    return React.createElement(react_1.Label, null, stringify(props.value));\n  }\n}, _a[\"AutoNumber\"] = function (props, col) {\n  if (index_1.stateData.Settings.length > 0 && index_1.stateData.Settings[0].attributes.indexOf(col.colDefs[col.columnIndex].name.toLowerCase()) > -1) {\n    return React.createElement(react_1.Label, null, stringify(props.value));\n  }\n}, _a[\"DateOnly\"] = function (props, col) {\n  if (index_1.stateData.Settings.length > 0 && index_1.stateData.Settings[0].attributes.indexOf(col.colDefs[col.columnIndex].name.toLowerCase()) > -1) {\n    return React.createElement(react_1.Label, null, stringify(props.value));\n  }\n}, _a[\"DateAndTime\"] = function (props, col) {\n  if (index_1.stateData.Settings.length > 0 && index_1.stateData.Settings[0].attributes.indexOf(col.colDefs[col.columnIndex].name.toLowerCase()) > -1) {\n    return React.createElement(react_1.Label, null, stringify(props.value));\n  }\n}, _a[\"Image\"] = function (props, col) {\n  if (index_1.stateData.Settings.length > 0 && index_1.stateData.Settings[0].attributes.indexOf(col.colDefs[col.columnIndex].name.toLowerCase()) > -1) {\n    return React.createElement(react_1.Label, null, stringify(props.value));\n  }\n}, _a[\"File\"] = function (props, col) {\n  if (index_1.stateData.Settings.length > 0 && index_1.stateData.Settings[0].attributes.indexOf(col.colDefs[col.columnIndex].name.toLowerCase()) > -1) {\n    return React.createElement(react_1.Label, null, stringify(props.value));\n  }\n}, _a[\"Persona\"] = function (props, col) {\n  if (index_1.stateData.Settings.length > 0 && index_1.stateData.Settings[0].attributes.indexOf(col.colDefs[col.columnIndex].name.toLowerCase()) > -1) {\n    return React.createElement(react_1.Label, null, stringify(props.value));\n  }\n}, _a[\"RichText\"] = function (props, col) {\n  if (index_1.stateData.Settings.length > 0 && index_1.stateData.Settings[0].attributes.indexOf(col.colDefs[col.columnIndex].name.toLowerCase()) > -1) {\n    return React.createElement(react_1.Label, null, stringify(props.value));\n  }\n}, _a[\"UniqueIdentifier\"] = function (props, col) {\n  if (index_1.stateData.Settings.length > 0 && index_1.stateData.Settings[0].attributes.indexOf(col.colDefs[col.columnIndex].name.toLowerCase()) > -1) {\n    return React.createElement(react_1.Label, null, stringify(props.value));\n  }\n}, _a);\nfunction stringify(value) {\n  console.log(value);\n  if (typeof value === \"function\") {\n    // Within this branch, `value` has type `Function`,\n    // so we can access the function's `name` property\n    var functionName = value.name || \"(anonymous)\";\n    return \"[function \".concat(functionName, \"]\");\n  }\n  if (value instanceof Date) {\n    // Within this branch, `value` has type `Date`,\n    // so we can call the `toISOString` method\n    return value.toISOString();\n  }\n  return String(value !== null && value !== void 0 ? value : '');\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./PAGridCustomizer/customizers/CellEditorOverrides.tsx?");

/***/ }),

/***/ "./PAGridCustomizer/customizers/CellRendererOverrides.tsx":
/*!****************************************************************!*\
  !*** ./PAGridCustomizer/customizers/CellRendererOverrides.tsx ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, exports) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.cellRendererOverrides = void 0;\nexports.cellRendererOverrides = {};\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./PAGridCustomizer/customizers/CellRendererOverrides.tsx?");

/***/ }),

/***/ "./PAGridCustomizer/index.ts":
/*!***********************************!*\
  !*** ./PAGridCustomizer/index.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("\n\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.stateData = exports.PAGridCustomizer = void 0;\nvar CellRendererOverrides_1 = __webpack_require__(/*! ./customizers/CellRendererOverrides */ \"./PAGridCustomizer/customizers/CellRendererOverrides.tsx\");\nvar CellEditorOverrides_1 = __webpack_require__(/*! ./customizers/CellEditorOverrides */ \"./PAGridCustomizer/customizers/CellEditorOverrides.tsx\");\nvar React = __webpack_require__(/*! react */ \"react\");\nvar stateData = {\n  Settings: [],\n  logicalName: ''\n};\nexports.stateData = stateData;\nvar PAGridCustomizer = /** @class */function () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function PAGridCustomizer() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   */\n  PAGridCustomizer.prototype.init = function (context, notifyOutputChanged, state) {\n    var _a, _b, _c, _d;\n    var contextObj = context;\n    stateData.logicalName = contextObj.client._customControlProperties.pageType === 'EntityList' ? (_b = (_a = contextObj.page) === null || _a === void 0 ? void 0 : _a.entityTypeName) !== null && _b !== void 0 ? _b : '' : (_d = (_c = contextObj.client._customControlProperties.descriptor.Parameters) === null || _c === void 0 ? void 0 : _c.TargetEntityType) !== null && _d !== void 0 ? _d : '';\n    var environmentVariableName = 'Grid Customizer';\n    context.webAPI.retrieveMultipleRecords(\"environmentvariabledefinition\", \"?$filter=displayname eq '\".concat(environmentVariableName, \"'&$select=environmentvariabledefinitionid&$expand=environmentvariabledefinition_environmentvariablevalue($select=value)\")).then(function (result) {\n      var current = result && result.entities ? result.entities[0] : {};\n      var value = current['environmentvariabledefinition_environmentvariablevalue'] ? current['environmentvariabledefinition_environmentvariablevalue'][0].value : null;\n      var models = value ? JSON.parse(value) : [];\n      stateData.Settings = models.filter(function (e) {\n        return e.logicalName == stateData.logicalName;\n      });\n    });\n    var eventName = context.parameters.EventName.raw;\n    if (eventName) {\n      var paOneGridCustomizer = {\n        cellRendererOverrides: CellRendererOverrides_1.cellRendererOverrides,\n        cellEditorOverrides: CellEditorOverrides_1.cellEditorOverrides\n      };\n      context.factory.fireEvent(eventName, paOneGridCustomizer);\n    }\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   * @returns ReactElement root react element for the control\r\n   */\n  PAGridCustomizer.prototype.updateView = function (context) {\n    return React.createElement(React.Fragment);\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n  PAGridCustomizer.prototype.getOutputs = function () {\n    return {};\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n  PAGridCustomizer.prototype.destroy = function () {\n    // Add code to cleanup control if necessary\n  };\n  return PAGridCustomizer;\n}();\nexports.PAGridCustomizer = PAGridCustomizer;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./PAGridCustomizer/index.ts?");

/***/ }),

/***/ "@fluentui/react":
/*!*************************************!*\
  !*** external "FluentUIReactv8290" ***!
  \*************************************/
/***/ ((module) => {

module.exports = FluentUIReactv8290;

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "React" ***!
  \************************/
/***/ ((module) => {

module.exports = React;

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__("./PAGridCustomizer/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('grid.PAGridCustomizer', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.PAGridCustomizer);
} else {
	var grid = grid || {};
	grid.PAGridCustomizer = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.PAGridCustomizer;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}